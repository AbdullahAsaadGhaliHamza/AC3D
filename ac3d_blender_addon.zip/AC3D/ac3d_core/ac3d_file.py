import struct
import os
from .ac3d_chunks import *

class AC3DFile:
    """Represents an AC3D file, containing multiple chunks"""
    
    def __init__(self):
        """Initialize an empty AC3D file"""
        self.chunks = []
        # Add a header chunk by default
        self.chunks.append(HeaderChunk())
    
    def add_chunk(self, chunk):
        """Add a chunk to the file"""
        self.chunks.append(chunk)
        return chunk
    
    def add_metadata(self, key, value):
        """Add metadata to the file"""
        # Find existing metadata chunk or create a new one
        metadata_chunk = self.find_chunk_of_type(MetadataChunk)
        if not metadata_chunk:
            metadata_chunk = MetadataChunk()
            self.add_chunk(metadata_chunk)
        
        metadata_chunk.add_entry(key, value)
    
    def find_chunk_of_type(self, chunk_type):
        """Find the first chunk of the specified type"""
        for chunk in self.chunks:
            if isinstance(chunk, chunk_type):
                return chunk
        return None
    
    def find_chunks_of_type(self, chunk_type):
        """Find all chunks of the specified type"""
        return [chunk for chunk in self.chunks if isinstance(chunk, chunk_type)]
    
    def save(self, filepath):
        """Save the AC3D file to disk"""
        with open(filepath, 'wb') as f:
            # Create or update TOC
            toc_chunk = self._find_or_create_toc()
            
            # Calculate offsets for TOC entries
            offset = 0
            entries = []
            
            for chunk in self.chunks:
                if not isinstance(chunk, TOCChunk):  # Skip TOC itself
                    chunk_type = chunk.get_type()
                    header_size = 16  # ChunkHeader size
                    data_size = chunk.get_data_size()
                    
                    entries.append(TOCEntry(chunk_type, offset, header_size + data_size))
                
                # Update offset for next chunk
                offset += 16 + chunk.get_data_size()  # header + data
            
            # Update TOC with entries
            toc_chunk.set_entries(entries)
            
            # Write all chunks
            for chunk in self.chunks:
                chunk.write(f)
            
            # Add an END chunk
            EndChunk().write(f)
    
    def load(self, filepath):
        """Load an AC3D file from disk"""
        with open(filepath, 'rb') as f:
            # Clear existing chunks
            self.chunks = []
            
            # Read chunks until END or EOF
            while True:
                # Read chunk header
                header_data = f.read(16)
                if not header_data or len(header_data) != 16:
                    break  # EOF
                
                # Parse header
                chunk_id, chunk_size, chunk_flags = struct.unpack('<IQI', header_data)
                
                # Check for END chunk
                if chunk_id == int.from_bytes(b'END ', byteorder='little'):
                    break
                
                # Create appropriate chunk
                chunk = self._create_chunk_from_id(chunk_id)
                if not chunk:
                    # Skip unknown chunk
                    f.seek(chunk_size, os.SEEK_CUR)
                    continue
                
                # Read chunk data
                chunk_data = f.read(chunk_size)
                if len(chunk_data) != chunk_size:
                    raise ValueError(f"Failed to read complete chunk data (expected {chunk_size} bytes)")
                
                # Parse chunk data
                chunk.read_data(chunk_data, chunk_flags)
                
                # Add to chunks list
                self.chunks.append(chunk)
        
        return True
    
    def _find_or_create_toc(self):
        """Find or create a TOC chunk"""
        # Look for existing TOC
        for chunk in self.chunks:
            if isinstance(chunk, TOCChunk):
                return chunk
        
        # Create new TOC after header
        toc_chunk = TOCChunk()
        
        # Insert after header (or at beginning if no header)
        if self.chunks and isinstance(self.chunks[0], HeaderChunk):
            self.chunks.insert(1, toc_chunk)
        else:
            self.chunks.insert(0, toc_chunk)
        
        return toc_chunk
    
    def _create_chunk_from_id(self, chunk_id):
        """Create a chunk instance based on its ID"""
        # Convert ID to string
        id_str = chunk_id.to_bytes(4, byteorder='little').decode('ascii')
        
        # Map ID to chunk class
        chunk_map = {
            'HEAD': HeaderChunk,
            'TOC ': TOCChunk,
            'MESH': MeshChunk,
            'MAT ': MaterialChunk,
            'TEXT': TextureChunk,
            'ANIM': AnimationChunk,
            'SKEL': SkeletonChunk,
            'XRFM': TransformChunk,
            'INST': InstanceChunk,
            'COLR': ColorChunk,
            'META': MetadataChunk,
            'END ': EndChunk
        }
        
        # Create appropriate chunk
        if id_str in chunk_map:
            return chunk_map[id_str]()
        
        return None