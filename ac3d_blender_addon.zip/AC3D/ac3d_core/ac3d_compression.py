import math
from .ac3d_chunks import CompressionMethod, Vector2, Vector3

def compress_mesh(mesh, error_threshold):
    """Apply compression to a mesh with automatic method selection"""
    
    if error_threshold > 0.01:
        # For larger error tolerances, quantization is usually sufficient
        compress_mesh_quantization(mesh, error_threshold)
    elif error_threshold > 0.001:
        # For medium error tolerances, delta encoding works well
        compress_mesh_delta(mesh, error_threshold)
    else:
        # For small error tolerances, prediction-based compression
        compress_mesh_prediction(mesh, error_threshold)
    
    # Always use octahedral encoding for normals
    compress_mesh_normals(mesh)

def compress_mesh_quantization(mesh, error_threshold):
    """Apply quantization-based compression to a mesh"""
    
    # Skip if no positions
    if not mesh.positions:
        return
    
    # Store original positions for error calculation
    original_positions = mesh.positions.copy()
    
    # Calculate bounding box
    min_pos = Vector3(float('inf'), float('inf'), float('inf'))
    max_pos = Vector3(float('-inf'), float('-inf'), float('-inf'))
    
    for pos in mesh.positions:
        min_pos.x = min(min_pos.x, pos.x)
        min_pos.y = min(min_pos.y, pos.y)
        min_pos.z = min(min_pos.z, pos.z)
        
        max_pos.x = max(max_pos.x, pos.x)
        max_pos.y = max(max_pos.y, pos.y)
        max_pos.z = max(max_pos.z, pos.z)
    
    # Calculate extents
    extents = Vector3(
        max_pos.x - min_pos.x,
        max_pos.y - min_pos.y,
        max_pos.z - min_pos.z
    )
    
    # Determine quantization precision based on error threshold
    bits_per_component = 16  # Default
    if error_threshold > 0.01:
        bits_per_component = 12
    elif error_threshold > 0.001:
        bits_per_component = 14
    elif error_threshold > 0.0001:
        bits_per_component = 16
    else:
        bits_per_component = 18
    
    # Calculate quantization scale
    quant_scale = (1 << bits_per_component) - 1
    
    # Quantize vertices
    for i in range(len(mesh.positions)):
        # Normalize to [0,1]
        nx = (mesh.positions[i].x - min_pos.x) / extents.x if extents.x > 0 else 0
        ny = (mesh.positions[i].y - min_pos.y) / extents.y if extents.y > 0 else 0
        nz = (mesh.positions[i].z - min_pos.z) / extents.z if extents.z > 0 else 0
        
        # Quantize
        qx = int(nx * quant_scale + 0.5)
        qy = int(ny * quant_scale + 0.5)
        qz = int(nz * quant_scale + 0.5)
        
        # Dequantize
        dx = (qx / quant_scale) * extents.x + min_pos.x
        dy = (qy / quant_scale) * extents.y + min_pos.y
        dz = (qz / quant_scale) * extents.z + min_pos.z
        
        # Update position with quantized values
        mesh.positions[i] = Vector3(dx, dy, dz)
    
    # Calculate error
    max_error = 0.0
    for i in range(len(mesh.positions)):
        dx = mesh.positions[i].x - original_positions[i].x
        dy = mesh.positions[i].y - original_positions[i].y
        dz = mesh.positions[i].z - original_positions[i].z
        
        error = math.sqrt(dx*dx + dy*dy + dz*dz)
        max_error = max(max_error, error)
    
    print(f"Mesh quantized with {bits_per_component} bits per component")
    print(f"Maximum error: {max_error}")

def compress_mesh_delta(mesh, error_threshold):
    """Apply delta-based compression to a mesh"""
    
    # Skip if no positions
    if not mesh.positions or len(mesh.positions) < 2:
        return
    
    # Store original positions for error calculation
    original_positions = mesh.positions.copy()
    
    # Use first vertex as reference
    reference = mesh.positions[0]
    
    # Process all vertices except the first one
    for i in range(1, len(mesh.positions)):
        # Calculate delta from reference
        dx = mesh.positions[i].x - reference.x
        dy = mesh.positions[i].y - reference.y
        dz = mesh.positions[i].z - reference.z
        
        # Determine quantization precision based on error threshold
        bits = 12
        if error_threshold > 0.01:
            bits = 10
        elif error_threshold > 0.001:
            bits = 12
        else:
            bits = 14
        
        # Calculate max delta and scale
        max_delta = max(abs(dx), abs(dy), abs(dz))
        scale = ((1 << (bits - 1)) - 1) / max_delta if max_delta > 0 else 1.0
        
        # Quantize deltas
        qdx = int(dx * scale)
        qdy = int(dy * scale)
        qdz = int(dz * scale)
        
        # Dequantize
        dx = qdx / scale
        dy = qdy / scale
        dz = qdz / scale
        
        # Update position
        mesh.positions[i] = Vector3(reference.x + dx, reference.y + dy, reference.z + dz)
    
    # Calculate error
    max_error = 0.0
    for i in range(len(mesh.positions)):
        dx = mesh.positions[i].x - original_positions[i].x
        dy = mesh.positions[i].y - original_positions[i].y
        dz = mesh.positions[i].z - original_positions[i].z
        
        error = math.sqrt(dx*dx + dy*dy + dz*dz)
        max_error = max(max_error, error)
    
    print(f"Mesh delta-compressed")
    print(f"Maximum error: {max_error}")
    
    # Set compression method
    mesh.set_compression_method(CompressionMethod.DELTA)

def compress_mesh_prediction(mesh, error_threshold):
    """Apply prediction-based compression to a mesh"""
    
    # Skip if not enough data
    if not mesh.positions or not mesh.triangles or len(mesh.positions) < 3:
        return
    
    # Store original positions for error calculation
    original_positions = mesh.positions.copy()
    
    # Build adjacency information
    adjacency = [[] for _ in range(len(mesh.positions))]
    
    for tri in mesh.triangles:
        a, b, c = tri.indices
        adjacency[a].extend([b, c])
        adjacency[b].extend([a, c])
        adjacency[c].extend([a, b])
    
    # Remove duplicates in adjacency lists
    for i in range(len(adjacency)):
        adjacency[i] = list(set(adjacency[i]))
    
    # Determine quantization precision based on error threshold
    bits = 10
    if error_threshold > 0.01:
        bits = 8
    elif error_threshold > 0.001:
        bits = 10
    else:
        bits = 12
    
    # For vertices with enough adjacent vertices, try parallelogram prediction
    for i in range(len(mesh.positions)):
        if len(adjacency[i]) >= 2:
            # Get two adjacent vertices
            adj1 = adjacency[i][0]
            adj2 = adjacency[i][1]
            
            # Find a shared neighbor (other than i)
            common = -1
            for n in adjacency[adj1]:
                if n != i and n in adjacency[adj2]:
                    common = n
                    break
            
            if common >= 0:
                # Predict position using parallelogram rule
                px = mesh.positions[adj1].x + mesh.positions[adj2].x - mesh.positions[common].x
                py = mesh.positions[adj1].y + mesh.positions[adj2].y - mesh.positions[common].y
                pz = mesh.positions[adj1].z + mesh.positions[adj2].z - mesh.positions[common].z
                
                # Calculate delta from prediction
                dx = mesh.positions[i].x - px
                dy = mesh.positions[i].y - py
                dz = mesh.positions[i].z - pz
                
                # Calculate max delta and scale for quantization
                max_delta = max(abs(dx), abs(dy), abs(dz))
                scale = ((1 << (bits - 1)) - 1) / max_delta if max_delta > 0 else 1.0
                
                # Quantize deltas
                qdx = int(dx * scale)
                qdy = int(dy * scale)
                qdz = int(dz * scale)
                
                # Dequantize
                dx = qdx / scale
                dy = qdy / scale
                dz = qdz / scale
                
                # Update position
                mesh.positions[i] = Vector3(px + dx, py + dy, pz + dz)
    
    # Calculate error
    max_error = 0.0
    for i in range(len(mesh.positions)):
        dx = mesh.positions[i].x - original_positions[i].x
        dy = mesh.positions[i].y - original_positions[i].y
        dz = mesh.positions[i].z - original_positions[i].z
        
        error = math.sqrt(dx*dx + dy*dy + dz*dz)
        max_error = max(max_error, error)
    
    print(f"Mesh prediction-compressed")
    print(f"Maximum error: {max_error}")
    
    # Set compression method
    mesh.set_compression_method(CompressionMethod.PREDICTION)

def compress_mesh_normals(mesh):
    """Compress mesh normals using octahedral encoding"""
    
    # Skip if no normals
    if not mesh.normals:
        return
    
    # Store original normals for error calculation
    original_normals = mesh.normals.copy()
    
    # Compress each normal
    for i in range(len(mesh.normals)):
        # Normalize the normal vector
        normal = mesh.normals[i]
        length = math.sqrt(normal.x*normal.x + normal.y*normal.y + normal.z*normal.z)
        if length > 0:
            normal.x /= length
            normal.y /= length
            normal.z /= length
        
        # Convert to octahedral representation
        sum_xyz = abs(normal.x) + abs(normal.y) + abs(normal.z)
        nx = normal.x / sum_xyz
        ny = normal.y / sum_xyz
        
        # Handle negative z
        if normal.z < 0:
            tx = (1.0 - abs(ny)) * (1.0 if nx >= 0 else -1.0)
            ty = (1.0 - abs(nx)) * (1.0 if ny >= 0 else -1.0)
            nx = tx
            ny = ty
        
        # Convert from [-1,1] to [0,1] for storage
        nx = (nx + 1.0) * 0.5
        ny = (ny + 1.0) * 0.5
        
        # Quantize to 8 bits per component
        qx = int(nx * 255 + 0.5)
        qy = int(ny * 255 + 0.5)
        
        # Dequantize
        nx = (qx / 255.0) * 2.0 - 1.0
        ny = (qy / 255.0) * 2.0 - 1.0
        
        # Convert back to 3D normal
        nz = 1.0 - abs(nx) - abs(ny)
        
        if nz < 0:
            # Handle negative z case
            tx = (1.0 - abs(ny)) * (1.0 if nx >= 0 else -1.0)
            ty = (1.0 - abs(nx)) * (1.0 if ny >= 0 else -1.0)
            nx = tx
            ny = ty
            nz = 1.0 - abs(nx) - abs(ny)
        
        # Normalize
        length = math.sqrt(nx*nx + ny*ny + nz*nz)
        if length > 0:
            nx /= length
            ny /= length
            nz /= length
        
        # Update normal
        mesh.normals[i] = Vector3(nx, ny, nz)
    
    # Calculate angular error
    max_angle_error = 0.0
    for i in range(len(mesh.normals)):
        # Calculate dot product between original and compressed normals
        dot = (
            original_normals[i].x * mesh.normals[i].x +
            original_normals[i].y * mesh.normals[i].y +
            original_normals[i].z * mesh.normals[i].z
        )
        
        # Clamp to [-1, 1] to avoid numerical issues
        dot = max(-1.0, min(1.0, dot))
        
        # Calculate angle in degrees
        angle = math.acos(dot) * 180.0 / math.pi
        max_angle_error = max(max_angle_error, angle)
    
    print(f"Normals compressed using octahedral encoding")
    print(f"Maximum angular error: {max_angle_error} degrees")

def compress_animation(animation, error_threshold):
    """Apply compression to animation channels"""
    
    for channel in animation.channels:
        # Skip if too few keyframes to compress
        if len(channel.keyframes) <= 2:
            continue
        
        # Store original keyframes for comparison
        original_keyframes = channel.keyframes.copy()
        
        # Apply Ramer-Douglas-Peucker algorithm to simplify animation curves
        # Start with just the first and last keyframes
        simplified = [channel.keyframes[0], channel.keyframes[-1]]
        
        # Recursively add important keyframes
        simplify_curve(channel.keyframes, 0, len(channel.keyframes) - 1, error_threshold, simplified)
        
        # Sort keyframes by time
        simplified.sort(key=lambda kf: kf.time)
        
        # Replace keyframes with simplified version
        channel.keyframes = simplified
        
        print(f"Animation channel compressed from {len(original_keyframes)} to {len(channel.keyframes)} keyframes")

def simplify_curve(keyframes, start, end, epsilon, result):
    """Recursively simplify an animation curve using Ramer-Douglas-Peucker algorithm"""
    
    if end - start <= 1:
        return
    
    # Find point with max error
    max_error = 0
    max_index = start
    
    # Get start and end keyframes
    start_kf = keyframes[start]
    end_kf = keyframes[end]
    
    # Calculate time range
    time_range = end_kf.time - start_kf.time
    
    for i in range(start + 1, end):
        # Interpolate position at this time
        t = (keyframes[i].time - start_kf.time) / time_range
        
        # Linear interpolation of translation
        ix = start_kf.transform.translation.x * (1 - t) + end_kf.transform.translation.x * t
        iy = start_kf.transform.translation.y * (1 - t) + end_kf.transform.translation.y * t
        iz = start_kf.transform.translation.z * (1 - t) + end_kf.transform.translation.z * t
        
        # Calculate error (difference between actual and interpolated)
        dx = keyframes[i].transform.translation.x - ix
        dy = keyframes[i].transform.translation.y - iy
        dz = keyframes[i].transform.translation.z - iz
        
        error = math.sqrt(dx*dx + dy*dy + dz*dz)
        
        # Also consider rotation error (simplified)
        # A full SLERP would be more accurate but more complex
        
        if error > max_error:
            max_error = error
            max_index = i
    
    # If max error is greater than epsilon, add this point and recurse
    if max_error > epsilon:
        result.append(keyframes[max_index])
        
        # Recurse on the two segments
        simplify_curve(keyframes, start, max_index, epsilon, result)
        simplify_curve(keyframes, max_index, end, epsilon, result)