import struct
import io
import enum
import math

# Enumerations

class ChunkType(enum.Enum):
    HEADER = b'HEAD'
    TOC = b'TOC '
    MESH = b'MESH'
    MATERIAL = b'MAT '
    TEXTURE = b'TEXT'
    ANIMATION = b'ANIM'
    SKELETON = b'SKEL'
    TRANSFORM = b'XRFM'
    INSTANCE = b'INST'
    COLOR = b'COLR'
    METADATA = b'META'
    END = b'END '

class CompressionMethod(enum.IntEnum):
    NONE = 0
    QUANTIZATION = 1
    PREDICTION = 2
    WAVELET = 3
    DELTA = 4
    OCTAHEDRAL = 5
    CUSTOM = 255

class TextureType(enum.IntEnum):
    DIFFUSE = 0
    NORMAL = 1
    SPECULAR = 2
    ROUGHNESS = 3
    METALLIC = 4
    AMBIENT_OCC = 5
    EMISSIVE = 6
    HEIGHT = 7
    CUSTOM = 255

class AnimationType(enum.IntEnum):
    SKELETAL = 0
    MORPH_TARGET = 1
    PROCEDURAL = 2
    CUSTOM = 255

# Basic data structures

class Vector2:
    def __init__(self, u=0.0, v=0.0):
        self.u = float(u)
        self.v = float(v)
    
    def __bytes__(self):
        return struct.pack('<ff', self.u, self.v)
    
    @classmethod
    def from_bytes(cls, data):
        u, v = struct.unpack('<ff', data)
        return cls(u, v)
    
    def __repr__(self):
        return f"Vector2({self.u}, {self.v})"

class Vector3:
    def __init__(self, x=0.0, y=0.0, z=0.0):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)
    
    def __bytes__(self):
        return struct.pack('<fff', self.x, self.y, self.z)
    
    @classmethod
    def from_bytes(cls, data):
        x, y, z = struct.unpack('<fff', data)
        return cls(x, y, z)
    
    def length(self):
        return math.sqrt(self.x*self.x + self.y*self.y + self.z*self.z)
    
    def normalize(self):
        length = self.length()
        if length > 0:
            self.x /= length
            self.y /= length
            self.z /= length
        return self
    
    def __repr__(self):
        return f"Vector3({self.x}, {self.y}, {self.z})"

class Vector4:
    def __init__(self, x=0.0, y=0.0, z=0.0, w=0.0):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)
        self.w = float(w)
    
    def __bytes__(self):
        return struct.pack('<ffff', self.x, self.y, self.z, self.w)
    
    @classmethod
    def from_bytes(cls, data):
        x, y, z, w = struct.unpack('<ffff', data)
        return cls(x, y, z, w)
    
    def __repr__(self):
        return f"Vector4({self.x}, {self.y}, {self.z}, {self.w})"

class Color:
    def __init__(self, r=1.0, g=1.0, b=1.0, a=1.0):
        self.r = float(r)
        self.g = float(g)
        self.b = float(b)
        self.a = float(a)
    
    def __bytes__(self):
        return struct.pack('<ffff', self.r, self.g, self.b, self.a)
    
    @classmethod
    def from_bytes(cls, data):
        r, g, b, a = struct.unpack('<ffff', data)
        return cls(r, g, b, a)
    
    def __repr__(self):
        return f"Color({self.r}, {self.g}, {self.b}, {self.a})"

class Quaternion:
    def __init__(self, x=0.0, y=0.0, z=0.0, w=1.0):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)
        self.w = float(w)
    
    def __bytes__(self):
        return struct.pack('<ffff', self.x, self.y, self.z, self.w)
    
    @classmethod
    def from_bytes(cls, data):
        x, y, z, w = struct.unpack('<ffff', data)
        return cls(x, y, z, w)
    
    def normalize(self):
        length = math.sqrt(self.x*self.x + self.y*self.y + self.z*self.z + self.w*self.w)
        if length > 0:
            self.x /= length
            self.y /= length
            self.z /= length
            self.w /= length
        return self
    
    def __repr__(self):
        return f"Quaternion({self.x}, {self.y}, {self.z}, {self.w})"

class Transform:
    def __init__(self, translation=None, rotation=None, scale=None):
        self.translation = translation or Vector3()
        self.rotation = rotation or Quaternion()
        self.scale = scale or Vector3(1.0, 1.0, 1.0)
    
    def __bytes__(self):
        return bytes(self.translation) + bytes(self.rotation) + bytes(self.scale)
    
    @classmethod
    def from_bytes(cls, data):
        translation = Vector3.from_bytes(data[0:12])
        rotation = Quaternion.from_bytes(data[12:28])
        scale = Vector3.from_bytes(data[28:40])
        return cls(translation, rotation, scale)
    
    def __repr__(self):
        return f"Transform({self.translation}, {self.rotation}, {self.scale})"

class Triangle:
    def __init__(self, a=0, b=0, c=0):
        self.indices = [int(a), int(b), int(c)]
    
    def __bytes__(self):
        return struct.pack('<III', *self.indices)
    
    @classmethod
    def from_bytes(cls, data):
        a, b, c = struct.unpack('<III', data)
        return cls(a, b, c)
    
    def __repr__(self):
        return f"Triangle({self.indices[0]}, {self.indices[1]}, {self.indices[2]})"

class KeyFrame:
    def __init__(self, time=0.0, transform=None):
        self.time = float(time)
        self.transform = transform or Transform()
    
    def __bytes__(self):
        return struct.pack('<f', self.time) + bytes(self.transform)
    
    @classmethod
    def from_bytes(cls, data):
        time = struct.unpack('<f', data[0:4])[0]
        transform = Transform.from_bytes(data[4:44])
        return cls(time, transform)
    
    def __repr__(self):
        return f"KeyFrame({self.time}, {self.transform})"

class TOCEntry:
    def __init__(self, chunk_type=ChunkType.HEADER, offset=0, size=0):
        self.chunk_type = chunk_type
        self.offset = offset
        self.size = size
    
    def __bytes__(self):
        return self.chunk_type.value + struct.pack('<QQ', self.offset, self.size)
    
    @classmethod
    def from_bytes(cls, data):
        chunk_type = ChunkType(data[0:4])
        offset, size = struct.unpack('<QQ', data[4:20])
        return cls(chunk_type, offset, size)

# Base Chunk class

class Chunk:
    """Base class for all AC3D chunks"""
    
    def __init__(self):
        self.flags = 0
    
    def get_type(self):
        """Get the chunk type"""
        raise NotImplementedError("Subclasses must implement get_type()")
    
    def get_data_size(self):
        """Get the size of the chunk data in bytes"""
        raise NotImplementedError("Subclasses must implement get_data_size()")
    
    def get_flags(self):
        """Get the chunk flags"""
        return self.flags
    
    def set_flags(self, flags):
        """Set the chunk flags"""
        self.flags = flags
    
    def write(self, file):
        """Write the chunk to a file"""
        # Write header
        chunk_type = self.get_type().value
        chunk_size = self.get_data_size()
        chunk_flags = self.get_flags()
        
        file.write(chunk_type)
        file.write(struct.pack('<QI', chunk_size, chunk_flags))
        
        # Write data
        data = self.to_bytes()
        file.write(data)
        
        return True
    
    def read_data(self, data, flags=0):
        """Parse the chunk data from bytes"""
        self.flags = flags
        self.from_bytes(data)
        return True
    
    def to_bytes(self):
        """Convert the chunk data to bytes"""
        raise NotImplementedError("Subclasses must implement to_bytes()")
    
    def from_bytes(self, data):
        """Parse the chunk data from bytes"""
        raise NotImplementedError("Subclasses must implement from_bytes()")

# Specific chunk implementations

class HeaderChunk(Chunk):
    MAGIC = 0x41433344  # "AC3D" in ASCII
    VERSION_MAJOR = 0
    VERSION_MINOR = 2
    
    def __init__(self):
        super().__init__()
        self.magic = self.MAGIC
        self.version_major = self.VERSION_MAJOR
        self.version_minor = self.VERSION_MINOR
        self.flags = 0
    
    def get_type(self):
        return ChunkType.HEADER
    
    def get_data_size(self):
        return 12  # magic(4) + version_major(2) + version_minor(2) + flags(4)
    
    def to_bytes(self):
        return struct.pack('<IHHI', self.magic, self.version_major, self.version_minor, self.flags)
    
    def from_bytes(self, data):
        self.magic, self.version_major, self.version_minor, self.flags = struct.unpack('<IHHI', data)
        
        if self.magic != self.MAGIC:
            raise ValueError(f"Invalid magic number: {self.magic:#x}, expected {self.MAGIC:#x}")
        
        return True

class TOCChunk(Chunk):
    def __init__(self):
        super().__init__()
        self.entries = []
    
    def get_type(self):
        return ChunkType.TOC
    
    def get_data_size(self):
        return 4 + len(self.entries) * 20  # entry_count(4) + entries
    
    def set_entries(self, entries):
        self.entries = entries
    
    def add_entry(self, entry):
        self.entries.append(entry)
    
    def to_bytes(self):
        data = struct.pack('<I', len(self.entries))
        for entry in self.entries:
            data += bytes(entry)
        return data
    
    def from_bytes(self, data):
        entry_count = struct.unpack('<I', data[0:4])[0]
        
        self.entries = []
        for i in range(entry_count):
            offset = 4 + i * 20
            entry_data = data[offset:offset+20]
            entry = TOCEntry.from_bytes(entry_data)
            self.entries.append(entry)
        
        return True

class MeshChunk(Chunk):
    # Mesh flags
    class MeshFlags:
        HAS_VERTEX_COLORS = (1 << 8)
        HAS_MULTIPLE_UVS = (1 << 9)
        HAS_TANGENTS = (1 << 10)
        HAS_BONE_WEIGHTS = (1 << 11)
    
    def __init__(self):
        super().__init__()
        self.positions = []
        self.normals = []
        self.tex_coords = []
        self.triangles = []
        self.tangents = []
        self.colors = []
        self.bone_indices = []
        self.bone_weights = []
        self.compression_method = CompressionMethod.NONE
    
    def get_type(self):
        return ChunkType.MESH
    
    def get_data_size(self):
        size = 12  # flags(4) + vertex_count(4) + triangle_count(4)
        
        # Add vertex data
        size += len(self.positions) * 12  # 3 floats per position
        size += len(self.normals) * 12    # 3 floats per normal
        size += len(self.tex_coords) * 8  # 2 floats per UV
        
        # Add triangle data
        size += len(self.triangles) * 12  # 3 uint32 per triangle
        
        # Add optional data
        if self.has_flag(self.MeshFlags.HAS_TANGENTS):
            size += len(self.tangents) * 16  # 4 floats per tangent
        
        if self.has_flag(self.MeshFlags.HAS_VERTEX_COLORS):
            size += len(self.colors) * 16  # 4 floats per color
        
        if self.has_flag(self.MeshFlags.HAS_BONE_WEIGHTS):
            size += len(self.bone_indices) * 16  # 4 uint32 per vertex
            size += len(self.bone_weights) * 16  # 4 floats per vertex
        
        return size
    
    def has_flag(self, flag):
        return (self.flags & flag) != 0
    
    def set_flag(self, flag, value=True):
        if value:
            self.flags |= flag
        else:
            self.flags &= ~flag
    
    def set_compression_method(self, method):
        self.compression_method = method
        # Update flags to include compression method
        self.flags = (self.flags & 0xFFFFFF00) | int(method)
    
    def add_vertex(self, position, normal, tex_coord):
        self.positions.append(position)
        self.normals.append(normal)
        self.tex_coords.append(tex_coord)
    
    def add_triangle(self, a, b, c):
        self.triangles.append(Triangle(a, b, c))
    
    def add_tangent(self, tangent):
        if len(self.tangents) < len(self.positions):
            self.tangents = [Vector4() for _ in range(len(self.positions))]
        
        self.tangents.append(tangent)
        self.set_flag(self.MeshFlags.HAS_TANGENTS)
    
    def add_color(self, color):
        if len(self.colors) < len(self.positions):
            self.colors = [Color() for _ in range(len(self.positions))]
        
        self.colors.append(color)
        self.set_flag(self.MeshFlags.HAS_VERTEX_COLORS)
    
    def add_bone_weights(self, vertex_index, indices, weights):
        if len(indices) != 4 or len(weights) != 4:
            raise ValueError("Bone weights must have exactly 4 entries")
        
        # Ensure arrays are large enough
        while len(self.bone_indices) <= vertex_index:
            self.bone_indices.append([0, 0, 0, 0])
            self.bone_weights.append([0.0, 0.0, 0.0, 0.0])
        
        self.bone_indices[vertex_index] = indices
        self.bone_weights[vertex_index] = weights
        self.set_flag(self.MeshFlags.HAS_BONE_WEIGHTS)
    
    def compress(self, error_threshold):
        """Apply compression with automatic method selection"""
        from .ac3d_compression import compress_mesh
        compress_mesh(self, error_threshold)
    
    def to_bytes(self):
        # Write header data
        data = struct.pack('<III', 
                           self.flags,
                           len(self.positions),
                           len(self.triangles))
        
        # Write positions
        for pos in self.positions:
            data += bytes(pos)
        
        # Write normals
        for normal in self.normals:
            data += bytes(normal)
        
        # Write texture coordinates
        for uv in self.tex_coords:
            data += bytes(uv)
        
        # Write triangles
        for tri in self.triangles:
            data += bytes(tri)
        
        # Write optional data
        if self.has_flag(self.MeshFlags.HAS_TANGENTS):
            for tangent in self.tangents:
                data += bytes(tangent)
        
        if self.has_flag(self.MeshFlags.HAS_VERTEX_COLORS):
            for color in self.colors:
                data += bytes(color)
        
        if self.has_flag(self.MeshFlags.HAS_BONE_WEIGHTS):
            for indices in self.bone_indices:
                data += struct.pack('<IIII', *indices)
            
            for weights in self.bone_weights:
                data += struct.pack('<ffff', *weights)
        
        return data
    
    def from_bytes(self, data):
        # Read header
        self.flags, vertex_count, triangle_count = struct.unpack('<III', data[0:12])
        offset = 12
        
        # Read positions
        self.positions = []
        for i in range(vertex_count):
            pos_data = data[offset:offset+12]
            self.positions.append(Vector3.from_bytes(pos_data))
            offset += 12
        
        # Read normals
        self.normals = []
        for i in range(vertex_count):
            normal_data = data[offset:offset+12]
            self.normals.append(Vector3.from_bytes(normal_data))
            offset += 12
        
        # Read texture coordinates
        self.tex_coords = []
        for i in range(vertex_count):
            uv_data = data[offset:offset+8]
            self.tex_coords.append(Vector2.from_bytes(uv_data))
            offset += 8
        
        # Read triangles
        self.triangles = []
        for i in range(triangle_count):
            tri_data = data[offset:offset+12]
            self.triangles.append(Triangle.from_bytes(tri_data))
            offset += 12
        
        # Read optional data if present
        if self.has_flag(self.MeshFlags.HAS_TANGENTS):
            self.tangents = []
            for i in range(vertex_count):
                tangent_data = data[offset:offset+16]
                self.tangents.append(Vector4.from_bytes(tangent_data))
                offset += 16
        
        if self.has_flag(self.MeshFlags.HAS_VERTEX_COLORS):
            self.colors = []
            for i in range(vertex_count):
                color_data = data[offset:offset+16]
                self.colors.append(Color.from_bytes(color_data))
                offset += 16
        
        if self.has_flag(self.MeshFlags.HAS_BONE_WEIGHTS):
            self.bone_indices = []
            for i in range(vertex_count):
                indices_data = data[offset:offset+16]
                indices = struct.unpack('<IIII', indices_data)
                self.bone_indices.append(list(indices))
                offset += 16
            
            self.bone_weights = []
            for i in range(vertex_count):
                weights_data = data[offset:offset+16]
                weights = struct.unpack('<ffff', weights_data)
                self.bone_weights.append(list(weights))
                offset += 16
        
        # Extract compression method from flags
        self.compression_method = CompressionMethod(self.flags & 0xFF)
        
        return True
    
    def get_positions(self):
        return self.positions
    
    def get_normals(self):
        return self.normals
    
    def get_tex_coords(self):
        return self.tex_coords
    
    def get_triangles(self):
        return self.triangles
    
    def get_tangents(self):
        return self.tangents
    
    def get_colors(self):
        return self.colors
    
    def get_bone_indices(self):
        return self.bone_indices
    
    def get_bone_weights(self):
        return self.bone_weights

class MaterialChunk(Chunk):
    # Material flags
    class MaterialFlags:
        HAS_DIFFUSE_TEXTURE  = (1 << 0)
        HAS_NORMAL_MAP       = (1 << 1)
        HAS_SPECULAR_MAP     = (1 << 2)
        HAS_EMISSIVE_MAP     = (1 << 3)
        HAS_ROUGHNESS_MAP    = (1 << 4)
        HAS_METALLIC_MAP     = (1 << 5)
        HAS_OCCLUSION_MAP    = (1 << 6)
        IS_TRANSPARENT       = (1 << 16)
        IS_DOUBLE_SIDED      = (1 << 17)
        IS_PBR_WORKFLOW      = (1 << 18)
    
    def __init__(self):
        super().__init__()
        self.diffuse = [0.8, 0.8, 0.8, 1.0]
        self.specular = [0.0, 0.0, 0.0]
        self.emissive = [0.0, 0.0, 0.0]
        self.shininess = 0.0
        self.roughness = 0.5
        self.metallic = 0.0
        self.occlusion = 1.0
        self.name = "Material"
    
    def get_type(self):
        return ChunkType.MATERIAL
    
    def get_data_size(self):
        # Calculate size: flags + diffuse + specular + emissive + shininess + PBR params + name
        return (4 +          # flags
                16 +         # diffuse (4 floats)
                12 +         # specular (3 floats)
                12 +         # emissive (3 floats)
                4 +          # shininess (1 float)
                4 +          # roughness (1 float)
                4 +          # metallic (1 float)
                4 +          # occlusion (1 float)
                len(self.name) + 1)  # name string + null terminator
    
    def set_name(self, name):
        self.name = name
    
    def set_diffuse(self, r, g, b, a=1.0):
        self.diffuse = [r, g, b, a]
        
        # Set transparent flag if alpha < 1
        if a < 0.99:
            self.flags |= self.MaterialFlags.IS_TRANSPARENT
    
    def set_specular(self, r, g, b, power=32.0):
        self.specular = [r, g, b]
        self.shininess = power
    
    def set_emissive(self, r, g, b):
        self.emissive = [r, g, b]
    
    def set_pbr_parameters(self, roughness, metallic, occlusion):
        self.roughness = roughness
        self.metallic = metallic
        self.occlusion = occlusion
        self.flags |= self.MaterialFlags.IS_PBR_WORKFLOW
    
    def set_double_sided(self, double_sided):
        if double_sided:
            self.flags |= self.MaterialFlags.IS_DOUBLE_SIDED
        else:
            self.flags &= ~self.MaterialFlags.IS_DOUBLE_SIDED
    
    def set_texture_flags(self, texture_flags):
        # Clear existing texture flags (first 7 bits)
        self.flags &= ~0x7F
        # Set new texture flags
        self.flags |= (texture_flags & 0x7F)
    
    def is_pbr(self):
        return (self.flags & self.MaterialFlags.IS_PBR_WORKFLOW) != 0
    
    def is_transparent(self):
        return (self.flags & self.MaterialFlags.IS_TRANSPARENT) != 0
    
    def is_double_sided(self):
        return (self.flags & self.MaterialFlags.IS_DOUBLE_SIDED) != 0
    
    def to_bytes(self):
        data = struct.pack('<I', self.flags)
        data += struct.pack('<ffff', *self.diffuse)
        data += struct.pack('<fff', *self.specular)
        data += struct.pack('<fff', *self.emissive)
        data += struct.pack('<f', self.shininess)
        data += struct.pack('<f', self.roughness)
        data += struct.pack('<f', self.metallic)
        data += struct.pack('<f', self.occlusion)
        data += self.name.encode('utf-8') + b'\0'
        return data
    
    def from_bytes(self, data):
        offset = 0
        
        self.flags = struct.unpack('<I', data[offset:offset+4])[0]
        offset += 4
        
        self.diffuse = list(struct.unpack('<ffff', data[offset:offset+16]))
        offset += 16
        
        self.specular = list(struct.unpack('<fff', data[offset:offset+12]))
        offset += 12
        
        self.emissive = list(struct.unpack('<fff', data[offset:offset+12]))
        offset += 12
        
        self.shininess = struct.unpack('<f', data[offset:offset+4])[0]
        offset += 4
        
        self.roughness = struct.unpack('<f', data[offset:offset+4])[0]
        offset += 4
        
        self.metallic = struct.unpack('<f', data[offset:offset+4])[0]
        offset += 4
        
        self.occlusion = struct.unpack('<f', data[offset:offset+4])[0]
        offset += 4
        
        # Read null-terminated name
        end = data.find(b'\0', offset)
        if end >= 0:
            self.name = data[offset:end].decode('utf-8')
        
        return True
    
    def get_name(self):
        return self.name
    
    def get_diffuse(self):
        return self.diffuse
    
    def get_specular(self):
        return self.specular
    
    def get_emissive(self):
        return self.emissive
    
    def get_shininess(self):
        return self.shininess
    
    def get_roughness(self):
        return self.roughness
    
    def get_metallic(self):
        return self.metallic
    
    def get_occlusion(self):
        return self.occlusion

class TextureChunk(Chunk):
    # Texture flags
    class TextureFlags:
        EMBEDDED_DATA     = (1 << 0)
        SRGB              = (1 << 1)
        COMPRESSED        = (1 << 2)
        MIPMAPS           = (1 << 3)
    
    def __init__(self):
        super().__init__()
        self.type = TextureType.DIFFUSE
        self.width = 0
        self.height = 0
        self.path = ""
        self.image_data = b''
    
    def get_type(self):
        return ChunkType.TEXTURE
    
    def get_data_size(self):
        size = 4 + 1 + 4 + 4 + len(self.path) + 1  # flags + type + width + height + path + null
        
        if self.has_embedded_data():
            size += 4 + len(self.image_data)  # data_size + image_data
        
        return size
    
    def set_path(self, path):
        self.path = path
        self.flags &= ~self.TextureFlags.EMBEDDED_DATA
    
    def set_type(self, texture_type):
        self.type = texture_type
    
    def set_dimensions(self, width, height):
        self.width = width
        self.height = height
    
    def set_image_data(self, data):
        self.image_data = data
        self.flags |= self.TextureFlags.EMBEDDED_DATA
    
    def set_srgb(self, is_srgb):
        if is_srgb:
            self.flags |= self.TextureFlags.SRGB
        else:
            self.flags &= ~self.TextureFlags.SRGB
    
    def has_embedded_data(self):
        return (self.flags & self.TextureFlags.EMBEDDED_DATA) != 0
    
    def is_srgb(self):
        return (self.flags & self.TextureFlags.SRGB) != 0
    
    def to_bytes(self):
        data = struct.pack('<IB', self.flags, int(self.type))
        data += struct.pack('<II', self.width, self.height)
        data += self.path.encode('utf-8') + b'\0'
        
        if self.has_embedded_data():
            data += struct.pack('<I', len(self.image_data))
            data += self.image_data
        
        return data
    
    def from_bytes(self, data):
        offset = 0
        
        self.flags, type_value = struct.unpack('<IB', data[offset:offset+5])
        offset += 5
        
        self.type = TextureType(type_value)
        
        self.width, self.height = struct.unpack('<II', data[offset:offset+8])
        offset += 8
        
        # Read null-terminated path
        end = data.find(b'\0', offset)
        if end >= 0:
            self.path = data[offset:end].decode('utf-8')
            offset = end + 1
        
        # Read embedded data if present
        if self.has_embedded_data() and offset < len(data):
            data_size = struct.unpack('<I', data[offset:offset+4])[0]
            offset += 4
            
            self.image_data = data[offset:offset+data_size]
        
        return True
    
    def get_texture_type(self):
        return self.type
    
    def get_path(self):
        return self.path
    
    def get_width(self):
        return self.width
    
    def get_height(self):
        return self.height
    
    def get_image_data(self):
        return self.image_data

class SkeletonChunk(Chunk):
    class Bone:
        def __init__(self, name="", parent_index=-1, local_transform=None, inverse_bind_pose=None):
            self.name = name
            self.parent_index = parent_index
            self.local_transform = local_transform or Transform()
            self.inverse_bind_pose = inverse_bind_pose or Transform()
    
    def __init__(self):
        super().__init__()
        self.bones = []
    
    def get_type(self):
        return ChunkType.SKELETON
    
    def get_data_size(self):
        size = 4 + 4  # flags + bone_count
        
        for bone in self.bones:
            size += len(bone.name) + 1  # name + null
            size += 4  # parent_index
            size += 40  # local_transform
            size += 40  # inverse_bind_pose
        
        return size
    
    def add_bone(self, name, parent_index, local_transform, inverse_bind_pose):
        bone = self.Bone(name, parent_index, local_transform, inverse_bind_pose)
        self.bones.append(bone)
    
    def to_bytes(self):
        data = struct.pack('<II', self.flags, len(self.bones))
        
        for bone in self.bones:
            data += bone.name.encode('utf-8') + b'\0'
            data += struct.pack('<i', bone.parent_index)
            data += bytes(bone.local_transform)
            data += bytes(bone.inverse_bind_pose)
        
        return data
    
    def from_bytes(self, data):
        offset = 0
        
        self.flags, bone_count = struct.unpack('<II', data[offset:offset+8])
        offset += 8
        
        self.bones = []
        for i in range(bone_count):
            # Read null-terminated name
            end = data.find(b'\0', offset)
            if end < 0:
                break
            
            name = data[offset:end].decode('utf-8')
            offset = end + 1
            
            # Read parent index
            parent_index = struct.unpack('<i', data[offset:offset+4])[0]
            offset += 4
            
            # Read transforms
            local_transform = Transform.from_bytes(data[offset:offset+40])
            offset += 40
            
            inverse_bind_pose = Transform.from_bytes(data[offset:offset+40])
            offset += 40
            
            # Add bone
            self.add_bone(name, parent_index, local_transform, inverse_bind_pose)
        
        return True
    
    def get_bones(self):
        return self.bones

class AnimationChunk(Chunk):
    class AnimationChannel:
        def __init__(self, target_bone_index=0):
            self.target_bone_index = target_bone_index
            self.keyframes = []
    
    def __init__(self):
        super().__init__()
        self.type = AnimationType.SKELETAL
        self.frame_rate = 30.0
        self.duration = 0.0
        self.name = "Animation"
        self.channels = []
    
    def get_type(self):
        return ChunkType.ANIMATION
    
    def get_data_size(self):
        size = (4 +                # flags
                1 +                # type
                4 + 4 +            # frame_rate + duration
                len(self.name) + 1 +  # name + null
                4)                 # channel_count
        
        for channel in self.channels:
            size += 4  # target_bone_index
            size += 4  # keyframe_count
            size += len(channel.keyframes) * 44  # time(4) + transform(40)
        
        return size
    
    def set_name(self, name):
        self.name = name
    
    def set_type(self, animation_type):
        self.type = animation_type
    
    def set_timing(self, frame_rate, duration):
        self.frame_rate = frame_rate
        self.duration = duration
    
    def add_channel(self, bone_index, keyframes):
        channel = self.AnimationChannel(bone_index)
        channel.keyframes = keyframes
        self.channels.append(channel)
    
    def compress(self, error_threshold):
        """Apply compression to animation channels"""
        from .ac3d_compression import compress_animation
        compress_animation(self, error_threshold)
    
    def to_bytes(self):
        data = struct.pack('<IB', self.flags, int(self.type))
        data += struct.pack('<ff', self.frame_rate, self.duration)
        data += self.name.encode('utf-8') + b'\0'
        data += struct.pack('<I', len(self.channels))
        
        for channel in self.channels:
            data += struct.pack('<II', channel.target_bone_index, len(channel.keyframes))
            
            for keyframe in channel.keyframes:
                data += bytes(keyframe)
        
        return data
    
    def from_bytes(self, data):
        offset = 0
        
        self.flags, type_value = struct.unpack('<IB', data[offset:offset+5])
        offset += 5
        
        self.type = AnimationType(type_value)
        
        self.frame_rate, self.duration = struct.unpack('<ff', data[offset:offset+8])
        offset += 8
        
        # Read null-terminated name
        end = data.find(b'\0', offset)
        if end >= 0:
            self.name = data[offset:end].decode('utf-8')
            offset = end + 1
        
        # Read channels
        channel_count = struct.unpack('<I', data[offset:offset+4])[0]
        offset += 4
        
        self.channels = []
        for i in range(channel_count):
            channel = self.AnimationChannel()
            
            # Read target bone index and keyframe count
            channel.target_bone_index, keyframe_count = struct.unpack('<II', data[offset:offset+8])
            offset += 8
            
            # Read keyframes
            channel.keyframes = []
            for j in range(keyframe_count):
                keyframe = KeyFrame.from_bytes(data[offset:offset+44])
                channel.keyframes.append(keyframe)
                offset += 44
            
            self.channels.append(channel)
        
        return True
    
    def get_name(self):
        return self.name
    
    def get_animation_type(self):
        return self.type
    
    def get_frame_rate(self):
        return self.frame_rate
    
    def get_duration(self):
        return self.duration
    
    def get_channels(self):
        return self.channels

class TransformChunk(Chunk):
    def __init__(self):
        super().__init__()
        self.transform = Transform()
        self.name = "Node"
    
    def get_type(self):
        return ChunkType.TRANSFORM
    
    def get_data_size(self):
        return 4 + 40 + len(self.name) + 1  # flags + transform + name + null
    
    def set_name(self, name):
        self.name = name
    
    def set_transform(self, transform):
        self.transform = transform
    
    def to_bytes(self):
        data = struct.pack('<I', self.flags)
        data += bytes(self.transform)
        data += self.name.encode('utf-8') + b'\0'
        return data
    
    def from_bytes(self, data):
        offset = 0
        
        self.flags = struct.unpack('<I', data[offset:offset+4])[0]
        offset += 4
        
        self.transform = Transform.from_bytes(data[offset:offset+40])
        offset += 40
        
        # Read null-terminated name
        end = data.find(b'\0', offset)
        if end >= 0:
            self.name = data[offset:end].decode('utf-8')
        
        return True
    
    def get_name(self):
        return self.name
    
    def get_transform(self):
        return self.transform

class InstanceChunk(Chunk):
    def __init__(self):
        super().__init__()
        self.source_mesh_index = 0
        self.transform = Transform()
        self.name = "Instance"
    
    def get_type(self):
        return ChunkType.INSTANCE
    
    def get_data_size(self):
        return 4 + 4 + 40 + len(self.name) + 1  # flags + source_index + transform + name + null
    
    def set_name(self, name):
        self.name = name
    
    def set_source_mesh_index(self, index):
        self.source_mesh_index = index
    
    def set_transform(self, transform):
        self.transform = transform
    
    def to_bytes(self):
        data = struct.pack('<II', self.flags, self.source_mesh_index)
        data += bytes(self.transform)
        data += self.name.encode('utf-8') + b'\0'
        return data
    
    def from_bytes(self, data):
        offset = 0
        
        self.flags, self.source_mesh_index = struct.unpack('<II', data[offset:offset+8])
        offset += 8
        
        self.transform = Transform.from_bytes(data[offset:offset+40])
        offset += 40
        
        # Read null-terminated name
        end = data.find(b'\0', offset)
        if end >= 0:
            self.name = data[offset:end].decode('utf-8')
        
        return True
    
    def get_name(self):
        return self.name
    
    def get_source_mesh_index(self):
        return self.source_mesh_index
    
    def get_transform(self):
        return self.transform

class MetadataChunk(Chunk):
    def __init__(self):
        super().__init__()
        self.entries = {}
    
    def get_type(self):
        return ChunkType.METADATA
    
    def get_data_size(self):
        size = 4 + 4  # flags + entry_count
        
        for key, value in self.entries.items():
            size += len(key) + 1  # key + null
            size += len(value) + 1  # value + null
        
        return size
    
    def add_entry(self, key, value):
        self.entries[key] = str(value)
    
    def to_bytes(self):
        data = struct.pack('<II', self.flags, len(self.entries))
        
        for key, value in self.entries.items():
            data += key.encode('utf-8') + b'\0'
            data += value.encode('utf-8') + b'\0'
        
        return data
    
    def from_bytes(self, data):
        offset = 0
        
        self.flags, entry_count = struct.unpack('<II', data[offset:offset+8])
        offset += 8
        
        self.entries = {}
        for i in range(entry_count):
            # Read null-terminated key
            key_end = data.find(b'\0', offset)
            if key_end < 0:
                break
            
            key = data[offset:key_end].decode('utf-8')
            offset = key_end + 1
            
            # Read null-terminated value
            value_end = data.find(b'\0', offset)
            if value_end < 0:
                break
            
            value = data[offset:value_end].decode('utf-8')
            offset = value_end + 1
            
            self.entries[key] = value
        
        return True
    
    def get_entries(self):
        return self.entries
    
    def get_value(self, key):
        return self.entries.get(key, "")

class EndChunk(Chunk):
    def __init__(self):
        super().__init__()
    
    def get_type(self):
        return ChunkType.END
    
    def get_data_size(self):
        return 0  # No data
    
    def to_bytes(self):
        return b''
    
    def from_bytes(self, data):
        return True

class ColorChunk(Chunk):
    def __init__(self):
        super().__init__()
        self.colors = []
    
    def get_type(self):
        return ChunkType.COLOR
    
    def get_data_size(self):
        return 4 + 4 + len(self.colors) * 16  # flags + color_count + colors
    
    def add_color(self, color):
        self.colors.append(color)
    
    def to_bytes(self):
        data = struct.pack('<II', self.flags, len(self.colors))
        
        for color in self.colors:
            data += bytes(color)
        
        return data
    
    def from_bytes(self, data):
        offset = 0
        
        self.flags, color_count = struct.unpack('<II', data[offset:offset+8])
        offset += 8
        
        self.colors = []
        for i in range(color_count):
            color_data = data[offset:offset+16]
            self.colors.append(Color.from_bytes(color_data))
            offset += 16
        
        return True
    
    def get_colors(self):
        return self.colors