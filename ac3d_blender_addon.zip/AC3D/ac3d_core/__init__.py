# Initialize the ac3d_core module
# This module contains Python implementations of the AC3D Format

# Import all core classes to make them available from ac3d_core
from .ac3d_file import AC3DFile
from .ac3d_chunks import *
from .ac3d_compression import *