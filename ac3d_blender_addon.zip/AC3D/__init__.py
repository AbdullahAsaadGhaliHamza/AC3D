bl_info = {
    "name": "AC3D Format",
    "author": "TLD_Productions",
    "version": (0, 2, 0),
    "blender": (3, 0, 0),
    "location": "File > Import-Export",
    "description": "Import-Export AC3D format files",
    "category": "Import-Export",
}

import bpy
from bpy_extras.io_utils import ImportHelper, ExportHelper
from bpy.props import StringProperty, BoolProperty, FloatProperty

# Import operator classes
from .operators.import_ac3d import ImportAC3D
from .operators.export_ac3d import ExportAC3D

def menu_func_import(self, context):
    self.layout.operator(ImportAC3D.bl_idname, text="AC3D (.ac3d)")

def menu_func_export(self, context):
    self.layout.operator(ExportAC3D.bl_idname, text="AC3D (.ac3d)")

def register():
    bpy.utils.register_class(ImportAC3D)
    bpy.utils.register_class(ExportAC3D)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)

def unregister():
    bpy.utils.unregister_class(ImportAC3D)
    bpy.utils.unregister_class(ExportAC3D)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)

if __name__ == "__main__":
    register()