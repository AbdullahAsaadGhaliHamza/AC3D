import bpy
import mathutils
from ..ac3d_core.ac3d_chunks import Vector2, Vector3, Vector4, Quaternion, Transform, Color

def blender_to_ac3d_vector3(vector):
    """Convert a Blender vector to an AC3D Vector3"""
    return Vector3(vector.x, vector.y, vector.z)

def blender_to_ac3d_vector2(vector):
    """Convert a Blender vector to an AC3D Vector2"""
    return Vector2(vector.x, vector.y)

def blender_to_ac3d_quaternion(quat):
    """Convert a Blender quaternion to an AC3D Quaternion"""
    return Quaternion(quat.x, quat.y, quat.z, quat.w)

def blender_to_ac3d_color(color):
    """Convert a Blender color to an AC3D Color"""
    if len(color) >= 4:
        return Color(color[0], color[1], color[2], color[3])
    else:
        return Color(color[0], color[1], color[2], 1.0)

def blender_to_ac3d_transform(obj):
    """Convert a Blender object transform to an AC3D Transform"""
    # Get object transform
    location = obj.location
    
    # Get rotation as quaternion
    if obj.rotation_mode == 'QUATERNION':
        rotation = obj.rotation_quaternion
    else:
        rotation = obj.rotation_euler.to_quaternion()
    
    scale = obj.scale
    
    # Create AC3D transform
    return Transform(
        blender_to_ac3d_vector3(location),
        blender_to_ac3d_quaternion(rotation),
        blender_to_ac3d_vector3(scale)
    )

def ac3d_to_blender_vector3(vector):
    """Convert an AC3D Vector3 to a Blender vector"""
    return mathutils.Vector((vector.x, vector.y, vector.z))

def ac3d_to_blender_vector2(vector):
    """Convert an AC3D Vector2 to a Blender vector"""
    return mathutils.Vector((vector.u, vector.v))

def ac3d_to_blender_quaternion(quat):
    """Convert an AC3D Quaternion to a Blender quaternion"""
    return mathutils.Quaternion((quat.w, quat.x, quat.y, quat.z))

def ac3d_to_blender_color(color):
    """Convert an AC3D Color to a Blender color"""
    return (color.r, color.g, color.b, color.a)

def ac3d_to_blender_transform(transform, obj):
    """Apply an AC3D Transform to a Blender object"""
    # Set location
    obj.location = ac3d_to_blender_vector3(transform.translation)
    
    # Set rotation
    obj.rotation_mode = 'QUATERNION'
    obj.rotation_quaternion = ac3d_to_blender_quaternion(transform.rotation)
    
    # Set scale
    obj.scale = ac3d_to_blender_vector3(transform.scale)

def find_principled_bsdf_node(material):
    """Find the Principled BSDF node in a material node tree"""
    if material and material.node_tree:
        for node in material.node_tree.nodes:
            if node.type == 'BSDF_PRINCIPLED':
                return node
    return None

def bone_to_ac3d_transforms(bone):
    """Convert a Blender bone to AC3D transforms"""
    # This is a simplified conversion that does not fully handle Blender's bone system
    # A production-ready implementation would need to handle different bone orientations
    
    # Get bone matrix in local space
    if bone.parent:
        local_matrix = bone.parent.matrix_local.inverted() @ bone.matrix_local
    else:
        local_matrix = bone.matrix_local
    
    # Extract components
    loc, rot, scale = local_matrix.decompose()
    
    # Create local transform
    local_transform = Transform(
        blender_to_ac3d_vector3(loc),
        blender_to_ac3d_quaternion(rot),
        blender_to_ac3d_vector3(scale)
    )
    
    # Inverse bind pose (simplified)
    inverse_matrix = bone.matrix_local.inverted()
    inv_loc, inv_rot, inv_scale = inverse_matrix.decompose()
    
    inverse_bind_pose = Transform(
        blender_to_ac3d_vector3(inv_loc),
        blender_to_ac3d_quaternion(inv_rot),
        blender_to_ac3d_vector3(inv_scale)
    )
    
    return local_transform, inverse_bind_pose