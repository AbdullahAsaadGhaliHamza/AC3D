import bpy
import bmesh
import os
from datetime import datetime
from ..ac3d_core.ac3d_file import AC3DFile
from ..ac3d_core.ac3d_chunks import MeshChunk, MaterialChunk, SkeletonChunk, TextureChunk, AnimationChunk, InstanceChunk
from ..utils.blender_conversions import find_principled_bsdf_node, ac3d_to_blender_vector3, ac3d_to_blender_vector2, ac3d_to_blender_transform

def import_ac3d_to_scene(context, filepath):
    """Import an AC3D file into the current Blender scene"""
    
    print(f"Importing AC3D file: {filepath}")
    
    # Create an AC3D file object and load the file
    ac3d_file = AC3DFile()
    
    try:
        ac3d_file.load(filepath)
    except Exception as e:
        print(f"Error loading AC3D file: {e}")
        return {'CANCELLED'}
    
    # Import materials first
    materials = import_materials(ac3d_file)
    
    # Import meshes
    objects = import_meshes(context, ac3d_file, materials)
    
    # Import skeletons
    armatures = import_skeletons(context, ac3d_file)
    
    # Import animations if skeletons exist
    if armatures and any(ac3d_file.find_chunks_of_type(AnimationChunk)):
        import_animations(ac3d_file, armatures)
    
    # Set up proper parent-child relationships for instance chunks
    setup_instances(context, ac3d_file, objects)
    
    print("AC3D import completed successfully")
    return {'FINISHED'}

def import_materials(ac3d_file):
    """Import materials from AC3D file to Blender"""
    
    material_map = {}
    
    for material_chunk in ac3d_file.find_chunks_of_type(MaterialChunk):
        # Create a new Blender material
        mat_name = material_chunk.get_name()
        mat = bpy.data.materials.new(mat_name)
        mat.use_nodes = True
        
        # Get the Principled BSDF node
        principled_bsdf = find_principled_bsdf_node(mat)
        
        if principled_bsdf:
            # Set basic material properties
            diffuse = material_chunk.get_diffuse()
            principled_bsdf.inputs["Base Color"].default_value = (diffuse[0], diffuse[1], diffuse[2], diffuse[3] if len(diffuse) > 3 else 1.0)
            
            # Set PBR properties if available
            if material_chunk.is_pbr():
                principled_bsdf.inputs["Roughness"].default_value = material_chunk.get_roughness()
                principled_bsdf.inputs["Metallic"].default_value = material_chunk.get_metallic()
                # Note: Principled BSDF doesn't have a direct AO input
            else:
                # Traditional shading model
                specular = material_chunk.get_specular()
                shininess = material_chunk.get_shininess()
                
                # Handle different Blender versions with different input names
                try:
                    # Try different possible input names for different Blender versions
                    if "Specular" in principled_bsdf.inputs:
                        principled_bsdf.inputs["Specular"].default_value = (specular[0] + specular[1] + specular[2]) / 3.0
                    elif "Specular IOR Level" in principled_bsdf.inputs:
                        principled_bsdf.inputs["Specular IOR Level"].default_value = (specular[0] + specular[1] + specular[2]) / 3.0
                    elif "Specular Tint" in principled_bsdf.inputs:
                        principled_bsdf.inputs["Specular Tint"].default_value = (specular[0] + specular[1] + specular[2]) / 3.0
                    else:
                        # If none of the known inputs exist, just skip this property
                        print("Warning: Could not find appropriate specular input in the shader")
                except Exception as e:
                    print(f"Warning: Could not set specular properties: {e}")
                
                # Convert shininess to roughness (inverse relationship)
                principled_bsdf.inputs["Roughness"].default_value = 1.0 - min(1.0, shininess / 64.0)
            
            # Set emission if available
            emissive = material_chunk.get_emissive()
            if any(emissive):  # If any component is non-zero
                try:
                    if "Emission Color" in principled_bsdf.inputs:
                        principled_bsdf.inputs["Emission Color"].default_value = (emissive[0], emissive[1], emissive[2], 1.0)
                        if "Emission Strength" in principled_bsdf.inputs:
                            principled_bsdf.inputs["Emission Strength"].default_value = 1.0
                    elif "Emission" in principled_bsdf.inputs:
                        principled_bsdf.inputs["Emission"].default_value = (emissive[0], emissive[1], emissive[2], 1.0)
                except Exception as e:
                    print(f"Warning: Could not set emission properties: {e}")
        
        # Store the material for later use
        material_map[mat_name] = mat
    
    # Import textures and assign to materials
    texture_chunks = ac3d_file.find_chunks_of_type(TextureChunk)
    for texture_chunk in texture_chunks:
        texture_type = texture_chunk.get_texture_type()
        texture_path = texture_chunk.get_path()
        
        # Try to load the texture
        image = None
        if texture_chunk.has_embedded_data():
            # Handle embedded texture data
            # This would require saving the data to a temp file
            pass
        elif os.path.exists(texture_path):
            try:
                image = bpy.data.images.load(texture_path)
            except Exception as e:
                print(f"Warning: Could not load texture {texture_path}: {e}")
        
        if image:
            # Find the material this texture belongs to
            # This would require mapping textures to materials
            pass
    
    return material_map

def import_meshes(context, ac3d_file, materials):
    """Import meshes from AC3D file to Blender"""
    
    objects = []
    
    for mesh_chunk in ac3d_file.find_chunks_of_type(MeshChunk):
        try:
            # Create a new mesh
            mesh_name = f"AC3DMesh_{len(objects)}"
            mesh = bpy.data.meshes.new(mesh_name)
            
            # Get vertex data
            positions = mesh_chunk.get_positions()
            normals = mesh_chunk.get_normals()
            texcoords = mesh_chunk.get_tex_coords()
            
            # Create vertices
            mesh.vertices.add(len(positions))
            for i, pos in enumerate(positions):
                mesh.vertices[i].co = ac3d_to_blender_vector3(pos)
            
            # Get triangle data
            triangles = mesh_chunk.get_triangles()
            
            # Create loops and polygons (different approach for Blender 4.0)
            # Prepare data for foreach_set
            loop_start = [i * 3 for i in range(len(triangles))]
            loop_indices = []
            for tri in triangles:
                loop_indices.extend([tri.indices[0], tri.indices[1], tri.indices[2]])
            
            # Create the polygons
            mesh.loops.add(len(triangles) * 3)
            mesh.polygons.add(len(triangles))
            
            # Set data using foreach_set which is faster and doesn't use read-only attributes
            mesh.loops.foreach_set("vertex_index", loop_indices)
            mesh.polygons.foreach_set("loop_start", loop_start)
            # The loop_total property is read-only, so we don't set it directly
            # Blender sets it automatically based on the difference between consecutive loop_start values
            
            # Set normals if available
            if len(normals) == len(positions):
                try:
                    mesh.create_normals_split()
                    for i, normal in enumerate(normals):
                        for loop in mesh.loops:
                            if loop.vertex_index == i:
                                loop.normal = ac3d_to_blender_vector3(normal)
                    mesh.use_auto_smooth = True
                except Exception as e:
                    print(f"Warning: Could not set custom normals: {e}")
            
            # Create UVs if available
            if len(texcoords) > 0:
                try:
                    uv_layer = mesh.uv_layers.new(name="UVMap")
                    for i, tri_idx in enumerate(range(0, len(loop_indices), 3)):
                        for j in range(3):
                            loop_idx = i * 3 + j
                            vertex_idx = loop_indices[tri_idx + j]
                            if vertex_idx < len(texcoords):
                                uv_layer.data[loop_idx].uv = ac3d_to_blender_vector2(texcoords[vertex_idx])
                except Exception as e:
                    print(f"Warning: Could not create UV map: {e}")
            
            # Create vertex colors if available
            if hasattr(mesh_chunk, 'has_flag') and mesh_chunk.has_flag(MeshChunk.MeshFlags.HAS_VERTEX_COLORS):
                colors = mesh_chunk.get_colors()
                if len(colors) > 0:
                    try:
                        color_layer = mesh.vertex_colors.new(name="Col")
                        for i, tri_idx in enumerate(range(0, len(loop_indices), 3)):
                            for j in range(3):
                                loop_idx = i * 3 + j
                                vertex_idx = loop_indices[tri_idx + j]
                                if vertex_idx < len(colors):
                                    color_layer.data[loop_idx].color = (
                                        colors[vertex_idx].r,
                                        colors[vertex_idx].g,
                                        colors[vertex_idx].b,
                                        colors[vertex_idx].a
                                    )
                    except Exception as e:
                        print(f"Warning: Could not create vertex colors: {e}")
            
            # Finalize the mesh
            try:
                mesh.validate()
                mesh.update()
            except Exception as e:
                print(f"Warning: Issue finalizing mesh: {e}")
            
            # Create an object with the mesh
            obj = bpy.data.objects.new(mesh_name, mesh)
            context.collection.objects.link(obj)
            objects.append(obj)
        except Exception as e:
            print(f"Error importing mesh: {e}")
    
    return objects

def import_skeletons(context, ac3d_file):
    """Import skeletons from AC3D file to Blender"""
    
    armatures = []
    
    for skeleton_chunk in ac3d_file.find_chunks_of_type(SkeletonChunk):
        try:
            # Create a new armature
            armature = bpy.data.armatures.new("AC3DSkeleton")
            armature_obj = bpy.data.objects.new("AC3DSkeleton", armature)
            context.collection.objects.link(armature_obj)
            
            # Set as active object to enter edit mode
            context.view_layer.objects.active = armature_obj
            bpy.ops.object.mode_set(mode='EDIT')
            
            # Get bone data
            bones = skeleton_chunk.get_bones()
            edit_bones = {}
            
            # First pass: create all bones
            for i, bone_data in enumerate(bones):
                edit_bone = armature.edit_bones.new(bone_data.name)
                edit_bones[i] = edit_bone
                
                # Set bone position and orientation
                # This would require converting AC3D transform to Blender bone transform
                local_transform = bone_data.local_transform
                
                # For simplicity, just set a default bone shape
                edit_bone.head = (0, 0, 0)
                edit_bone.tail = (0, 0.1, 0)
            
            # Second pass: set parent-child relationships
            for i, bone_data in enumerate(bones):
                if bone_data.parent_index >= 0 and bone_data.parent_index < len(bones):
                    edit_bones[i].parent = edit_bones[bone_data.parent_index]
            
            # Exit edit mode
            bpy.ops.object.mode_set(mode='OBJECT')
            armatures.append(armature_obj)
        except Exception as e:
            print(f"Warning: Issue importing skeleton: {e}")
            # Exit edit mode if we're stuck in it
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except:
                pass
    
    return armatures

def import_animations(ac3d_file, armatures):
    """Import animations from AC3D file to Blender"""
    
    for animation_chunk in ac3d_file.find_chunks_of_type(AnimationChunk):
        try:
            anim_name = animation_chunk.get_name()
            
            # Create a new action
            action = bpy.data.actions.new(name=anim_name)
            
            # Get animation data
            channels = animation_chunk.get_channels()
            frame_rate = animation_chunk.get_frame_rate()
            duration = animation_chunk.get_duration()
            
            # Process each animation channel
            for channel in channels:
                bone_index = channel.target_bone_index
                keyframes = channel.keyframes
                
                # Skip if no target armature or bone
                if not armatures or bone_index >= len(armatures[0].data.bones):
                    continue
                
                # Get the bone
                bone = armatures[0].data.bones[bone_index]
                
                # Create fcurves for location, rotation, and scale
                for i in range(3):  # x, y, z
                    fcurve_loc = action.fcurves.new(f'pose.bones["{bone.name}"].location', index=i)
                    fcurve_rot = action.fcurves.new(f'pose.bones["{bone.name}"].rotation_quaternion', index=i)
                    fcurve_scale = action.fcurves.new(f'pose.bones["{bone.name}"].scale', index=i)
                    
                    # Add keyframes
                    for keyframe in keyframes:
                        time = keyframe.time
                        frame = int(time * frame_rate)
                        
                        # Get transform components
                        location = keyframe.transform.translation
                        rotation = keyframe.transform.rotation
                        scale = keyframe.transform.scale
                        
                        # Add keyframe points
                        fcurve_loc.keyframe_points.insert(frame, getattr(location, 'xyz'[i]))
                        fcurve_rot.keyframe_points.insert(frame, getattr(rotation, 'xyz'[i]))
                        fcurve_scale.keyframe_points.insert(frame, getattr(scale, 'xyz'[i]))
                
                # Add w component for quaternion rotation
                fcurve_rot_w = action.fcurves.new(f'pose.bones["{bone.name}"].rotation_quaternion', index=3)
                for keyframe in keyframes:
                    time = keyframe.time
                    frame = int(time * frame_rate)
                    rotation = keyframe.transform.rotation
                    fcurve_rot_w.keyframe_points.insert(frame, rotation.w)
            
            # Assign the action to the armature
            if armatures:
                if not armatures[0].animation_data:
                    armatures[0].animation_data_create()
                armatures[0].animation_data.action = action
        except Exception as e:
            print(f"Warning: Issue importing animation: {e}")

def setup_instances(context, ac3d_file, objects):
    """Set up instances and their transformations"""
    
    # Process instance chunks
    for instance_chunk in ac3d_file.find_chunks_of_type(InstanceChunk):
        try:
            source_index = instance_chunk.get_source_mesh_index()
            
            # Skip if source mesh doesn't exist
            if source_index >= len(objects):
                continue
            
            # Get source object
            source_obj = objects[source_index]
            
            # Create a new instance
            instance_name = instance_chunk.get_name() or f"Instance_{source_obj.name}"
            instance = bpy.data.objects.new(instance_name, source_obj.data)
            context.collection.objects.link(instance)
            
            # Set transform
            transform = instance_chunk.get_transform()
            ac3d_to_blender_transform(transform, instance)
        except Exception as e:
            print(f"Warning: Issue setting up instance: {e}")