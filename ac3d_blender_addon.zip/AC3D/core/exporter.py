import bpy
import bmesh
import os
import math
from datetime import datetime
from mathutils import Vector, Quaternion, Matrix
from ..ac3d_core.ac3d_file import AC3DFile
from ..ac3d_core.ac3d_chunks import (
    MeshChunk, MaterialChunk, SkeletonChunk, 
    TextureChunk, AnimationChunk, InstanceChunk,
    MetadataChunk, Transform, Vector3, Vector2,
    Quaternion as AC3DQuaternion, KeyFrame, Color
)

def export_scene_to_ac3d(context, filepath, use_compression=True, error_threshold=0.001,
                        export_textures=True, embed_textures=False, export_animations=True):
    """Export the current Blender scene to an AC3D file"""
    
    print(f"Exporting scene to AC3D: {filepath}")
    
    # Create a new AC3D file
    ac3d_file = AC3DFile()
    
    # Add metadata
    ac3d_file.add_metadata("Creator", f"Blender {bpy.app.version_string}")
    ac3d_file.add_metadata("Date", datetime.now().strftime("%Y-%m-%d"))
    ac3d_file.add_metadata("Exporter", "Blender AC3D Exporter v0.2")
    
    # Export materials
    material_indices = export_materials(ac3d_file, export_textures, embed_textures)
    
    # Export meshes
    mesh_mapping = export_meshes(ac3d_file, context, material_indices, use_compression, error_threshold)
    
    # Export armatures (skeletons)
    armature_mapping = export_armatures(ac3d_file, context)
    
    # Export animations if requested
    if export_animations and armature_mapping:
        export_animations_to_ac3d(ac3d_file, context, armature_mapping)
    
    # Export instances (duplicates)
    export_instances(ac3d_file, context, mesh_mapping)
    
    # Save the file
    try:
        ac3d_file.save(filepath)
        print(f"Successfully exported AC3D file to {filepath}")
        return {'FINISHED'}
    except Exception as e:
        print(f"Error saving AC3D file: {e}")
        return {'CANCELLED'}

def export_materials(ac3d_file, export_textures, embed_textures):
    """Export Blender materials to AC3D materials"""
    
    material_indices = {}
    
    for i, mat in enumerate(bpy.data.materials):
        if mat.name in material_indices:
            continue  # Skip duplicates
        
        # Create a new material chunk
        material_chunk = MaterialChunk()
        material_chunk.set_name(mat.name)
        
        # Check if material uses nodes
        if mat.use_nodes:
            # Try to find principled BSDF node
            principled_node = None
            for node in mat.node_tree.nodes:
                if node.type == 'BSDF_PRINCIPLED':
                    principled_node = node
                    break
            
            if principled_node:
                # Get PBR parameters
                base_color = principled_node.inputs["Base Color"].default_value
                metallic = principled_node.inputs["Metallic"].default_value
                roughness = principled_node.inputs["Roughness"].default_value
                
                # Set material properties
                material_chunk.set_diffuse(base_color[0], base_color[1], base_color[2], base_color[3])
                material_chunk.set_pbr_parameters(roughness, metallic, 1.0)  # Assume full ambient occlusion
                
                # Check for emission
                if "Emission Color" in principled_node.inputs and "Emission Strength" in principled_node.inputs:
                    emission_color = principled_node.inputs["Emission Color"].default_value
                    emission_strength = principled_node.inputs["Emission Strength"].default_value
                    
                    if emission_strength > 0:
                        material_chunk.set_emissive(
                            emission_color[0] * emission_strength,
                            emission_color[1] * emission_strength,
                            emission_color[2] * emission_strength
                        )
                
                # Export textures if enabled
                if export_textures:
                    # Find texture connections
                    texture_flags = 0
                    
                    # Check for base color texture
                    base_color_socket = principled_node.inputs["Base Color"]
                    if base_color_socket.is_linked:
                        from_node = base_color_socket.links[0].from_node
                        if from_node.type == 'TEX_IMAGE' and from_node.image:
                            texture_flags |= MaterialChunk.MaterialFlags.HAS_DIFFUSE_TEXTURE
                            export_texture(ac3d_file, from_node.image, TextureType.DIFFUSE, embed_textures)
                    
                    # Check for other PBR textures
                    # ... (similar checks for normal, roughness, metallic maps)
                    
                    # Set texture flags
                    material_chunk.set_texture_flags(texture_flags)
            else:
                # Fallback for non-principled materials
                diffuse_color = mat.diffuse_color if hasattr(mat, "diffuse_color") else [0.8, 0.8, 0.8, 1.0]
                material_chunk.set_diffuse(diffuse_color[0], diffuse_color[1], diffuse_color[2], diffuse_color[3] if len(diffuse_color) > 3 else 1.0)
        else:
            # Legacy materials
            diffuse_color = mat.diffuse_color if hasattr(mat, "diffuse_color") else [0.8, 0.8, 0.8, 1.0]
            material_chunk.set_diffuse(diffuse_color[0], diffuse_color[1], diffuse_color[2], diffuse_color[3] if len(diffuse_color) > 3 else 1.0)
        
        # Add the material to the file
        ac3d_file.add_chunk(material_chunk)
        material_indices[mat.name] = i
    
    return material_indices

def export_texture(ac3d_file, image, texture_type, embed):
    """Export a Blender image as an AC3D texture"""
    
    texture_chunk = TextureChunk()
    texture_chunk.set_type(texture_type)
    texture_chunk.set_dimensions(image.size[0], image.size[1])
    
    # Set sRGB flag for color textures
    if texture_type == TextureType.DIFFUSE or texture_type == TextureType.EMISSIVE:
        texture_chunk.set_srgb(True)
    
    if embed:
        # Embed the texture data
        # This would require loading the image pixels and storing them
        pass  # Not implemented in this example
    else:
        # Store the file path
        texture_chunk.set_path(bpy.path.abspath(image.filepath))
    
    ac3d_file.add_chunk(texture_chunk)
    return texture_chunk

def export_meshes(ac3d_file, context, material_indices, use_compression, error_threshold):
    """Export Blender meshes to AC3D meshes"""
    
    mesh_mapping = {}  # Maps Blender objects to AC3D mesh indices
    
    # Process all mesh objects in the scene
    for i, obj in enumerate(context.scene.objects):
        if obj.type != 'MESH':
            continue
        
        # Skip instances (will be handled separately)
        if obj.data in mesh_mapping:
            continue
        
        # Create a new mesh chunk
        mesh_chunk = MeshChunk()
        
        # Get a copy of the mesh with modifiers applied
        depsgraph = context.evaluated_depsgraph_get()
        mesh = obj.evaluated_get(depsgraph).to_mesh()
        
        # Triangulate the mesh
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.triangulate(bm, faces=bm.faces)
        bm.to_mesh(mesh)
        bm.free()
        
        # Export vertices
        for vert in mesh.vertices:
            # Transform vertex to world space
            position = obj.matrix_world @ vert.co
            normal = (obj.matrix_world.inverted().transposed().to_3x3() @ vert.normal).normalized()
            
            # Create AC3D vectors
            ac3d_position = Vector3(position.x, position.y, position.z)
            ac3d_normal = Vector3(normal.x, normal.y, normal.z)
            
            # Default UV (will be overridden if UV data exists)
            ac3d_uv = Vector2(0, 0)
            
            # Add vertex to the mesh chunk
            mesh_chunk.add_vertex(ac3d_position, ac3d_normal, ac3d_uv)
        
        # Export UVs if available
        if mesh.uv_layers.active:
            uv_layer = mesh.uv_layers.active.data
            for poly in mesh.polygons:
                for loop_idx in poly.loop_indices:
                    loop = mesh.loops[loop_idx]
                    vertex_idx = loop.vertex_index
                    uv = uv_layer[loop_idx].uv
                    
                    # Update UV coordinates for this vertex
                    ac3d_uv = Vector2(uv.x, uv.y)
                    # This would actually need to update the existing vertex
                    # or create a new one with the same position/normal but different UV
            
        # Export vertex colors if available
        if mesh.vertex_colors.active:
            color_layer = mesh.vertex_colors.active.data
            for poly in mesh.polygons:
                for loop_idx in poly.loop_indices:
                    loop = mesh.loops[loop_idx]
                    vertex_idx = loop.vertex_index
                    col = color_layer[loop_idx].color
                    
                    # Add color to this vertex
                    ac3d_color = Color(col[0], col[1], col[2], col[3] if len(col) > 3 else 1.0)
                    # Again, this would need to update the existing vertex data
        
        # Export triangles
        for poly in mesh.polygons:
            # Each polygon should be a triangle after triangulation
            if len(poly.vertices) == 3:
                mesh_chunk.add_triangle(poly.vertices[0], poly.vertices[1], poly.vertices[2])
        
        # Apply compression if requested
        if use_compression:
            mesh_chunk.compress(error_threshold)
        
        # Add the mesh to the file
        ac3d_file.add_chunk(mesh_chunk)
        
        # Store the mapping for later use with instances
        mesh_mapping[obj.data] = i
        
        # Clean up
        obj.to_mesh_clear()
    
    return mesh_mapping

def export_armatures(ac3d_file, context):
    """Export Blender armatures to AC3D skeletons"""
    
    armature_mapping = {}  # Maps Blender armatures to AC3D skeleton indices
    
    for i, obj in enumerate(context.scene.objects):
        if obj.type != 'ARMATURE':
            continue
        
        # Create a new skeleton chunk
        skeleton_chunk = SkeletonChunk()
        
        # Process bones
        bone_index_map = {}  # Maps bone names to indices
        for j, bone in enumerate(obj.data.bones):
            bone_index_map[bone.name] = j
        
        for j, bone in enumerate(obj.data.bones):
            # Get parent index
            parent_index = -1
            if bone.parent:
                parent_index = bone_index_map.get(bone.parent.name, -1)
            
            # Get bone transform
            # This would need to convert Blender's bone system to AC3D transforms
            # For simplicity, just use identity transforms here
            local_transform = Transform(
                Vector3(0, 0, 0),
                AC3DQuaternion(0, 0, 0, 1),
                Vector3(1, 1, 1)
            )
            
            inverse_bind_pose = Transform(
                Vector3(0, 0, 0),
                AC3DQuaternion(0, 0, 0, 1),
                Vector3(1, 1, 1)
            )
            
            # Add bone to skeleton
            skeleton_chunk.add_bone(bone.name, parent_index, local_transform, inverse_bind_pose)
        
        # Add the skeleton to the file
        ac3d_file.add_chunk(skeleton_chunk)
        armature_mapping[obj] = i
    
    return armature_mapping

def export_animations_to_ac3d(ac3d_file, context, armature_mapping):
    """Export Blender animations to AC3D animations"""
    
    for armature_obj, skeleton_index in armature_mapping.items():
        # Skip if armature has no animation data
        if not armature_obj.animation_data:
            continue
        
        # Process each action
        for action in bpy.data.actions:
            # Create a new animation chunk
            animation_chunk = AnimationChunk()
            animation_chunk.set_name(action.name)
            animation_chunk.set_type(AnimationType.SKELETAL)
            
            # Calculate frame rate and duration
            fps = context.scene.render.fps / context.scene.render.fps_base
            frame_start = int(action.frame_range[0])
            frame_end = int(action.frame_range[1])
            duration = (frame_end - frame_start) / fps
            
            animation_chunk.set_timing(fps, duration)
            
            # Process bone animation data
            bone_channels = {}
            
            for fcurve in action.fcurves:
                # Parse the data path to get bone name and property
                if not fcurve.data_path.startswith('pose.bones["'):
                    continue
                
                # Extract bone name and property
                parts = fcurve.data_path.split('"].')
                if len(parts) != 2:
                    continue
                
                bone_name = parts[0][12:]  # Remove 'pose.bones["'
                property_name = parts[1]
                
                # Initialize channel for this bone if needed
                if bone_name not in bone_channels:
                    bone_channels[bone_name] = {}
                
                # Store fcurve by property and index
                if property_name not in bone_channels[bone_name]:
                    bone_channels[bone_name][property_name] = {}
                
                bone_channels[bone_name][property_name][fcurve.array_index] = fcurve
            
            # Create keyframes for each bone
            for bone_name, properties in bone_channels.items():
                # Skip if bone doesn't exist
                if bone_name not in armature_obj.data.bones:
                    continue
                
                # Get bone index
                bone_index = list(armature_obj.data.bones).index(armature_obj.data.bones[bone_name])
                
                # Create keyframes list
                keyframes = []
                
                # Find all unique frames in fcurves
                frames = set()
                for prop_name, indices in properties.items():
                    for index, fcurve in indices.items():
                        for keyframe in fcurve.keyframe_points:
                            frames.add(int(keyframe.co[0]))
                
                # Create a keyframe for each frame
                for frame in sorted(frames):
                    time = (frame - frame_start) / fps
                    
                    # Default transform values
                    location = Vector((0, 0, 0))
                    rotation = Quaternion((1, 0, 0, 0))
                    scale = Vector((1, 1, 1))
                    
                    # Get location from fcurves
                    if 'location' in properties:
                        for i in range(3):
                            if i in properties['location']:
                                location[i] = properties['location'][i].evaluate(frame)
                    
                    # Get rotation from fcurves
                    if 'rotation_quaternion' in properties:
                        for i in range(4):
                            if i in properties['rotation_quaternion']:
                                rotation[i] = properties['rotation_quaternion'][i].evaluate(frame)
                    
                    # Get scale from fcurves
                    if 'scale' in properties:
                        for i in range(3):
                            if i in properties['scale']:
                                scale[i] = properties['scale'][i].evaluate(frame)
                    
                    # Create AC3D transform
                    transform = Transform(
                        Vector3(location.x, location.y, location.z),
                        AC3DQuaternion(rotation.x, rotation.y, rotation.z, rotation.w),
                        Vector3(scale.x, scale.y, scale.z)
                    )
                    
                    # Create keyframe
                    keyframe = KeyFrame(time, transform)
                    keyframes.append(keyframe)
                
                # Add animation channel for this bone
                animation_chunk.add_channel(bone_index, keyframes)
            
            # Compress the animation if it has channels
            if animation_chunk.get_channels():
                animation_chunk.compress(0.01)  # 1cm error threshold
                ac3d_file.add_chunk(animation_chunk)

def export_instances(ac3d_file, context, mesh_mapping):
    """Export mesh instances as AC3D instance chunks"""
    
    # Find duplicate instances (objects sharing the same mesh data)
    mesh_instances = {}
    for obj in context.scene.objects:
        if obj.type != 'MESH':
            continue
        
        # Skip if the mesh is not in our mapping (shouldn't happen)
        if obj.data not in mesh_mapping:
            continue
        
        mesh_index = mesh_mapping[obj.data]
        
        # First instance is the original, others are duplicates
        if mesh_index not in mesh_instances:
            mesh_instances[mesh_index] = [obj]
        else:
            mesh_instances[mesh_index].append(obj)
    
    # Create instance chunks for duplicates
    for mesh_index, objects in mesh_instances.items():
        # Skip if there's only one instance (the original)
        if len(objects) <= 1:
            continue
        
        # The first object is considered the original
        for i in range(1, len(objects)):
            obj = objects[i]
            
            # Create instance chunk
            instance_chunk = InstanceChunk()
            instance_chunk.set_name(obj.name)
            instance_chunk.set_source_mesh_index(mesh_index)
            
            # Get object transform
            location = obj.location
            rotation = obj.rotation_quaternion if obj.rotation_mode == 'QUATERNION' else obj.rotation_euler.to_quaternion()
            scale = obj.scale
            
            # Create AC3D transform
            transform = Transform(
                Vector3(location.x, location.y, location.z),
                AC3DQuaternion(rotation.x, rotation.y, rotation.z, rotation.w),
                Vector3(scale.x, scale.y, scale.z)
            )
            
            instance_chunk.set_transform(transform)
            
            # Add to file
            ac3d_file.add_chunk(instance_chunk)