import bpy
from bpy_extras.io_utils import ExportHelper
from bpy.props import StringProperty, BoolProperty, FloatProperty

class ExportAC3D(bpy.types.Operator, ExportHelper):
    """Export to AC3D format"""
    bl_idname = "export_scene.ac3d"
    bl_label = "Export AC3D"
    filename_ext = ".ac3d"
    
    filter_glob: StringProperty(default="*.ac3d", options={'HIDDEN'})
    
    use_compression: BoolProperty(
        name="Use Compression",
        description="Compress mesh data to reduce file size",
        default=True,
    )
    
    error_threshold: FloatProperty(
        name="Error Threshold",
        description="Maximum error for compression in Blender units",
        default=0.001,
        min=0.0001,
        max=0.1,
    )
    
    export_textures: BoolProperty(
        name="Export Textures",
        description="Export texture data",
        default=True,
    )
    
    embed_textures: BoolProperty(
        name="Embed Textures",
        description="Embed textures in the AC3D file",
        default=False,
    )
    
    export_animations: BoolProperty(
        name="Export Animations",
        description="Export animation data",
        default=True,
    )
    
    def execute(self, context):
        from ..core.exporter import export_scene_to_ac3d
        return export_scene_to_ac3d(
            context, 
            self.filepath,
            self.use_compression,
            self.error_threshold,
            self.export_textures,
            self.embed_textures,
            self.export_animations
        )