import bpy
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty

class ImportAC3D(bpy.types.Operator, ImportHelper):
    """Import an AC3D file"""
    bl_idname = "import_scene.ac3d"
    bl_label = "Import AC3D"
    filename_ext = ".ac3d"
    
    filter_glob: StringProperty(default="*.ac3d", options={'HIDDEN'})
    
    def execute(self, context):
        from ..core.importer import import_ac3d_to_scene
        return import_ac3d_to_scene(context, self.filepath)